# Original Discord security bot starter

This is an original Zynrax-inspired starter, not a copy of Zynrax's private source code, branding, or proprietary assets. It includes working slash-command foundations and a conservative anti-nuke monitor that logs suspicious actions rather than automatically banning people.

## Requirements
- Node.js 20.11+
- A Discord application/bot created at https://discord.com/developers/applications
- A VPS or local machine

## Setup
1. Install Node.js 20.11 or newer.
2. Extract this folder and open a terminal inside it.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Fill in `DISCORD_TOKEN` and `CLIENT_ID`. For instant test-server commands, also set `GUILD_ID`.
6. In Discord Developer Portal → Bot, enable **Server Members Intent**. Enable **Message Content Intent** only if you later add prefix commands.
7. Invite the bot with `bot` and `applications.commands` scopes. Grant only the permissions required by the features you use.
8. Run `npm run deploy`, then `npm start`.

## Included slash commands
- `/help`, `/ping`
- `/antinuke status|enable|disable` (monitor is disabled by default)
- `/whitelist add|remove|list`
- `/lockdown` and `/unlock`
- `/ban`, `/kick`, `/timeout`, `/purge`
- `/serverinfo`, `/userinfo`, `/avatar`, `/poll`

## Important safety notes
- Set `ENABLE_ANTINUKE=true` only after testing. The included monitor logs high-risk actions and does not automatically punish accounts.
- Discord role hierarchy and bot permissions still apply.
- Keep `.env` private. Never share your bot token.
- Slash commands are registered to the server in `GUILD_ID` when provided; otherwise they are registered globally.
- This is a functional starter, not a complete reproduction of every feature advertised by Zynrax. Music streaming, ticket panels/transcripts, giveaway scheduling, web dashboard, welcome configuration, and advanced anti-nuke enforcement are not implemented yet.
