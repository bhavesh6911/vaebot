const Database = require('better-sqlite3');
const path = require('node:path');
const fs = require('node:fs');

const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'bot.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    guild_id TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY (guild_id, key)
  );
  CREATE TABLE IF NOT EXISTS whitelist (
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (guild_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS security_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    actor_id TEXT,
    action TEXT NOT NULL,
    target_id TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
module.exports = {
  get(guildId, key, fallback = null) {
    const row = db.prepare('SELECT value FROM settings WHERE guild_id=? AND key=?').get(guildId, key);
    return row ? row.value : fallback;
  },
  set(guildId, key, value) {
    db.prepare(`INSERT INTO settings(guild_id,key,value) VALUES(?,?,?)
      ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value`).run(guildId, key, String(value));
  },
  whitelistAdd(guildId, userId, addedBy) {
    db.prepare('INSERT OR IGNORE INTO whitelist(guild_id,user_id,added_by) VALUES(?,?,?)')
      .run(guildId, userId, addedBy);
  },
  whitelistRemove(guildId, userId) {
    return db.prepare('DELETE FROM whitelist WHERE guild_id=? AND user_id=?').run(guildId, userId).changes > 0;
  },
  whitelistHas(guildId, userId) {
    return !!db.prepare('SELECT 1 FROM whitelist WHERE guild_id=? AND user_id=?').get(guildId, userId);
  },
  whitelistList(guildId) {
    return db.prepare('SELECT user_id, added_by, added_at FROM whitelist WHERE guild_id=? ORDER BY added_at').all(guildId);
  },
  logSecurity(guildId, actorId, action, targetId) {
    db.prepare('INSERT INTO security_events(guild_id,actor_id,action,target_id) VALUES(?,?,?,?)')
      .run(guildId, actorId || null, action, targetId || null);
  }
};
