const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType
} = require('discord.js');
const db = require('../db');
const { embed, isOwnerOrAdmin } = require('../util');

module.exports = [
  {
    data: new SlashCommandBuilder().setName('ping').setDescription('Show bot latency.'),
    async execute(i) { await i.reply({ embeds: [embed(`Pong! 🏓 API: **${Math.round(i.client.ws.ping)}ms**`)], ephemeral: true }); }
  },
  {
    data: new SlashCommandBuilder().setName('help').setDescription('Show available commands.'),
    async execute(i) {
      const e = new EmbedBuilder().setColor(0x5865F2).setTitle('Security Bot • Commands')
        .setDescription('An original multipurpose bot starter. Use `/` to browse commands.')
        .addFields(
          { name: 'Security', value: '`/antinuke` `/whitelist` `/lockdown` `/unlock`' },
          { name: 'Moderation', value: '`/ban` `/kick` `/timeout` `/purge`' },
          { name: 'Utility', value: '`/ping` `/serverinfo` `/userinfo` `/avatar` `/poll`' }
        ).setFooter({ text: 'Configure each module before using it in a live server.' });
      await i.reply({ embeds: [e], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('serverinfo').setDescription('Show information about this server.'),
    async execute(i) {
      const g = i.guild;
      await i.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(g.name)
        .setThumbnail(g.iconURL({ size: 256 })).addFields(
          { name: 'Server ID', value: g.id, inline: true },
          { name: 'Members', value: String(g.memberCount), inline: true },
          { name: 'Created', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true }
        )], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('userinfo').setDescription('Show information about a server member.')
      .addUserOption(o => o.setName('user').setDescription('Member to inspect').setRequired(false)),
    async execute(i) {
      const user = i.options.getUser('user') || i.user;
      const member = await i.guild.members.fetch(user.id).catch(() => null);
      const e = new EmbedBuilder().setColor(0x5865F2).setTitle(user.tag || user.username)
        .setThumbnail(user.displayAvatarURL({ size: 256 })).addFields(
          { name: 'User ID', value: user.id },
          { name: 'Account created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
          { name: 'Joined server', value: member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : 'Unknown' }
        );
      await i.reply({ embeds: [e], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('avatar').setDescription('Show a user avatar.')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(false)),
    async execute(i) {
      const user = i.options.getUser('user') || i.user;
      await i.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`${user.username}'s avatar`)
        .setImage(user.displayAvatarURL({ size: 1024 }))], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('poll').setDescription('Create a simple yes/no poll.')
      .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true).setMaxLength(250)),
    async execute(i) {
      const m = await i.reply({ content: `📊 **${i.options.getString('question')}**`, fetchReply: true });
      await m.react('👍'); await m.react('👎');
    }
  },
  {
    data: new SlashCommandBuilder().setName('whitelist').setDescription('Manage anti-nuke trusted users.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(s => s.setName('add').setDescription('Trust a user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand(s => s.setName('remove').setDescription('Remove a trusted user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand(s => s.setName('list').setDescription('List trusted users')),
    async execute(i) {
      if (!isOwnerOrAdmin(i)) return i.reply({ content: 'Only the server owner or an administrator can do this.', ephemeral: true });
      const sub = i.options.getSubcommand();
      if (sub === 'add') {
        const u = i.options.getUser('user');
        db.whitelistAdd(i.guildId, u.id, i.user.id);
        return i.reply({ embeds: [embed(`✅ Added **${u.tag}** to the security whitelist.`)], ephemeral: true });
      }
      if (sub === 'remove') {
        const u = i.options.getUser('user');
        const removed = db.whitelistRemove(i.guildId, u.id);
        return i.reply({ embeds: [embed(removed ? `Removed **${u.tag}** from the whitelist.` : 'That user was not on the whitelist.', removed ? 0x57F287 : 0xFEE75C)], ephemeral: true });
      }
      const rows = db.whitelistList(i.guildId);
      return i.reply({ embeds: [embed(rows.length ? rows.map(r => `• <@${r.user_id}> (\`${r.user_id}\`)`).join('\\n') : 'The whitelist is empty.', 0x5865F2)], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('antinuke').setDescription('Configure the anti-nuke event monitor.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(s => s.setName('status').setDescription('Show monitor status'))
      .addSubcommand(s => s.setName('enable').setDescription('Enable event logging monitor'))
      .addSubcommand(s => s.setName('disable').setDescription('Disable event logging monitor')),
    async execute(i) {
      if (!isOwnerOrAdmin(i)) return i.reply({ content: 'Only the server owner or an administrator can do this.', ephemeral: true });
      const sub = i.options.getSubcommand();
      if (sub === 'enable') db.set(i.guildId, 'antinuke_enabled', 'true');
      if (sub === 'disable') db.set(i.guildId, 'antinuke_enabled', 'false');
      const enabled = db.get(i.guildId, 'antinuke_enabled', process.env.ENABLE_ANTINUKE === 'true' ? 'true' : 'false') === 'true';
      return i.reply({ embeds: [embed(`Anti-nuke event monitor: **${enabled ? 'ENABLED' : 'DISABLED'}**\\n\\nThis starter records and logs suspicious events only. It does not automatically punish users.`, enabled ? 0x57F287 : 0xFEE75C)], ephemeral: true });
    }
  },
  {
    data: new SlashCommandBuilder().setName('lockdown').setDescription('Prevent @everyone from sending messages in text channels.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(i) {
      if (!isOwnerOrAdmin(i)) return i.reply({ content: 'Administrator permission required.', ephemeral: true });
      await i.deferReply({ ephemeral: true });
      let changed = 0;
      for (const [, ch] of i.guild.channels.cache) {
        if (!ch.isTextBased() || !ch.permissionOverwrites) continue;
        await ch.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: false }, { reason: `Lockdown by ${i.user.tag}` }).then(() => changed++).catch(() => {});
      }
      await i.editReply({ embeds: [embed(`🔒 Lockdown attempted. Updated **${changed}** text channels. Review channel-specific overwrites afterward.`, 0xED4245)] });
    }
  },
  {
    data: new SlashCommandBuilder().setName('unlock').setDescription('Allow @everyone to send messages in text channels.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(i) {
      if (!isOwnerOrAdmin(i)) return i.reply({ content: 'Administrator permission required.', ephemeral: true });
      await i.deferReply({ ephemeral: true });
      let changed = 0;
      for (const [, ch] of i.guild.channels.cache) {
        if (!ch.isTextBased() || !ch.permissionOverwrites) continue;
        await ch.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: null }, { reason: `Unlock by ${i.user.tag}` }).then(() => changed++).catch(() => {});
      }
      await i.editReply({ embeds: [embed(`🔓 Unlock attempted. Updated **${changed}** text channels. Review channel-specific overwrites afterward.`)] });
    }
  },
  {
    data: new SlashCommandBuilder().setName('ban').setDescription('Ban a server member.')
      .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
      .addUserOption(o => o.setName('user').setDescription('Member to ban').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false).setMaxLength(400)),
    async execute(i) {
      if (!i.memberPermissions.has(PermissionFlagsBits.BanMembers)) return i.reply({ content: 'You need Ban Members permission.', ephemeral: true });
      const user = i.options.getUser('user'), reason = i.options.getString('reason') || `No reason provided by ${i.user.tag}`;
      if (user.id === i.user.id || user.id === i.client.user.id || user.id === i.guild.ownerId) return i.reply({ content: 'That user cannot be banned.', ephemeral: true });
      try { await i.guild.members.ban(user.id, { reason }); await i.reply({ embeds: [embed(`🔨 Banned **${user.tag}**.\\nReason: ${reason}`)] }); }
      catch { await i.reply({ content: 'Ban failed. Check role hierarchy and bot permissions.', ephemeral: true }); }
    }
  },
  {
    data: new SlashCommandBuilder().setName('kick').setDescription('Kick a server member.')
      .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
      .addUserOption(o => o.setName('user').setDescription('Member to kick').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false).setMaxLength(400)),
    async execute(i) {
      if (!i.memberPermissions.has(PermissionFlagsBits.KickMembers)) return i.reply({ content: 'You need Kick Members permission.', ephemeral: true });
      const user = i.options.getUser('user'), member = await i.guild.members.fetch(user.id).catch(() => null);
      if (!member || user.id === i.guild.ownerId || user.id === i.user.id) return i.reply({ content: 'That member cannot be kicked.', ephemeral: true });
      try { await member.kick(i.options.getString('reason') || `Kicked by ${i.user.tag}`); await i.reply({ embeds: [embed(`👢 Kicked **${user.tag}**.`)] }); }
      catch { await i.reply({ content: 'Kick failed. Check role hierarchy and bot permissions.', ephemeral: true }); }
    }
  },
  {
    data: new SlashCommandBuilder().setName('timeout').setDescription('Timeout a member.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
      .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true))
      .addIntegerOption(o => o.setName('minutes').setDescription('Duration in minutes (1–10080)').setRequired(true).setMinValue(1).setMaxValue(10080))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false).setMaxLength(400)),
    async execute(i) {
      if (!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers)) return i.reply({ content: 'You need Moderate Members permission.', ephemeral: true });
      const user = i.options.getUser('user'), member = await i.guild.members.fetch(user.id).catch(() => null);
      if (!member || user.id === i.guild.ownerId || user.id === i.user.id) return i.reply({ content: 'That member cannot be timed out.', ephemeral: true });
      try { await member.timeout(i.options.getInteger('minutes') * 60000, i.options.getString('reason') || `Timed out by ${i.user.tag}`); await i.reply({ embeds: [embed(`⏳ Timed out **${user.tag}** for ${i.options.getInteger('minutes')} minutes.`)] }); }
      catch { await i.reply({ content: 'Timeout failed. Check role hierarchy and bot permissions.', ephemeral: true }); }
    }
  },
  {
    data: new SlashCommandBuilder().setName('purge').setDescription('Delete recent messages in this channel.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addIntegerOption(o => o.setName('amount').setDescription('Number of messages (1–100)').setRequired(true).setMinValue(1).setMaxValue(100)),
    async execute(i) {
      if (!i.memberPermissions.has(PermissionFlagsBits.ManageMessages)) return i.reply({ content: 'You need Manage Messages permission.', ephemeral: true });
      if (!i.channel?.isTextBased() || !i.channel.bulkDelete) return i.reply({ content: 'This channel does not support bulk delete.', ephemeral: true });
      const result = await i.channel.bulkDelete(i.options.getInteger('amount'), true).catch(() => null);
      if (!result) return i.reply({ content: 'Purge failed. Messages older than 14 days cannot be bulk-deleted.', ephemeral: true });
      await i.reply({ content: `🧹 Deleted ${result.size} recent messages.`, ephemeral: true });
    }
  }
];
