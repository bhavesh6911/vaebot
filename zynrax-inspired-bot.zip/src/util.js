const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('./db');

function embed(description, color = 0x57F287) {
  return new EmbedBuilder().setColor(color).setDescription(description).setTimestamp();
}
function isOwnerOrAdmin(interaction) {
  return interaction.guild && (
    interaction.guild.ownerId === interaction.user.id ||
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
  );
}
async function sendLog(guild, message) {
  const channelId = db.get(guild.id, 'log_channel');
  if (!channelId) return;
  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (channel?.isTextBased()) await channel.send({ embeds: [embed(message, 0xFEE75C)] }).catch(() => {});
}
module.exports = { embed, isOwnerOrAdmin, sendLog };
