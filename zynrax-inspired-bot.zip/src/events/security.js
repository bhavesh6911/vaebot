const { AuditLogEvent, Events } = require('discord.js');
const db = require('../db');
const { sendLog } = require('../util');

const eventMap = [
  [Events.ChannelDelete, AuditLogEvent.ChannelDelete, 'channel_delete'],
  [Events.GuildBanAdd, AuditLogEvent.MemberBanAdd, 'member_ban'],
  [Events.GuildRoleDelete, AuditLogEvent.RoleDelete, 'role_delete']
];

module.exports = function registerSecurity(client) {
  for (const [eventName, auditType, label] of eventMap) {
    client.on(eventName, async (target) => {
      const guild = target.guild;
      if (!guild) return;
      const enabled = db.get(guild.id, 'antinuke_enabled', process.env.ENABLE_ANTINUKE === 'true' ? 'true' : 'false') === 'true';
      if (!enabled) return;
      try {
        const logs = await guild.fetchAuditLogs({ type: auditType, limit: 1 });
        const entry = logs.entries.first();
        if (!entry || Date.now() - entry.createdTimestamp > 12_000) return;
        const actorId = entry.executor?.id;
        db.logSecurity(guild.id, actorId, label, target.id);
        const trusted = actorId && (actorId === guild.ownerId || db.whitelistHas(guild.id, actorId));
        await sendLog(guild, `⚠️ **Security event:** ${label}\\nActor: ${actorId ? `<@${actorId}> (\`${actorId}\`)` : 'Unknown'}\\nTarget ID: \`${target.id}\`\\nTrusted: **${trusted ? 'yes' : 'no'}**\\n_Action recorded only; no automatic punishment was taken._`);
      } catch (err) {
        console.error(`Security monitor error (${label}):`, err.message);
      }
    });
  }
};
